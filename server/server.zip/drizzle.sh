npx drizzle-kit generate
npx drizzle-kit push